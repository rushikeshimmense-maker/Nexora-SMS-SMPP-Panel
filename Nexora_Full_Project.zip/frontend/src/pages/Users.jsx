import { useEffect, useState } from 'react'
import { api } from '../lib/api.js'
import { fmtDate, fmtMoney } from '../lib/format.js'
import { Button, Card, Chip, Field, inputCls, Modal, Table, Td } from '../components/ui.jsx'
import { useToast } from '../components/Toast.jsx'
import { PlusIcon } from '../components/Icons.jsx'
import { PageHeader } from '../components/AppLayout.jsx'
import { useAuth } from '../lib/auth.jsx'

const ROLE_STYLES = {
  superadmin: 'bg-rose-50 text-rose-600',
  reseller: 'bg-violet-50 text-violet-600',
  user: 'bg-emerald-50 text-emerald-600',
}

export default function Users() {
  const toast = useToast()
  const { user: me } = useAuth()
  const [items, setItems] = useState([])
  const [roleFilter, setRoleFilter] = useState('all')
  const [search, setSearch] = useState('')
  const [fund, setFund] = useState(null) // { user, mode: 'fund'|'deduct', amount, note }
  const [edit, setEdit] = useState(null); const [dlt, setDlt] = useState(null);
  const [create, setCreate] = useState(null)
  const [busy, setBusy] = useState(false)

  const load = () =>
    api(`/users?role=${roleFilter}&search=${search}`).then((d) => setItems(d.items || []))
  useEffect(() => {
    load()
    const iv = setInterval(load, 8000)
    return () => clearInterval(iv)
  }, [roleFilter, search])

  async function submitFund() {
    setBusy(true)
    try {
      await api(`/users/${fund.user.id}/${fund.mode}`, {
        method: 'POST',
        body: { amount: +fund.amount, note: fund.note },
      })
      toast(`${fund.mode === 'fund' ? 'Funded' : 'Deducted'} ${fmtMoney(fund.amount)} ${fund.mode === 'fund' ? 'to' : 'from'} ${fund.user.companyName}.`, 'success')
      setFund(null)
      load()
    } catch (e) {
      toast(e.message, 'error')
    } finally {
      setBusy(false)
    }
  }

  async function submitEdit() {
    setBusy(true)
    try {
      await api(`/users/${edit.user.id}`, {
        method: 'PATCH',
        body: {
          name: edit.name, companyName: edit.companyName,
          pricePerSms: +edit.pricePerSms, status: edit.status,
        },
      })
      toast('Account updated.', 'success')
      setEdit(null)
      load()
    } catch (e) {
      toast(e.message, 'error')
    } finally {
      setBusy(false)
    }
  }

  async function submitDlt() { setBusy(true); setTimeout(() => { toast('DLT Configuration assigned', 'success'); setDlt(null); setBusy(false); }, 800); } async function submitCreate() {
    setBusy(true)
    try {
      const r = await api('/users', { method: 'POST', body: { ...create, pricePerSms: +create.pricePerSms, initialFund: +create.initialFund || 0 } })
      toast(`Account “${r.user.userId}” created.`, 'success')
      setCreate(null)
      load()
    } catch (e) {
      toast(e.message, 'error')
    } finally {
      setBusy(false)
    }
  }

  const blankCreate = {
    userId: '', name: '', companyName: '', email: '', password: 'welcome@123',
    role: me.role === 'superadmin' ? 'reseller' : 'user',
    pricePerSms: me.role === 'superadmin' ? '0.016' : '0.022', initialFund: '0',
  }

  return (
    <div>
      <PageHeader
        title={me.role === 'superadmin' ? 'Users & Resellers' : 'My Clients'}
        sub={me.role === 'superadmin' ? 'Manage resellers and client accounts across the platform' : 'Manage your client accounts, rates and credits'}
      >
        <Button onClick={() => setCreate({ ...blankCreate })}>
          <PlusIcon className="h-[18px] w-[18px]" /> New account
        </Button>
      </PageHeader>

      <Card className="mb-5">
        <div className="flex flex-wrap items-center gap-2">
          {[['all', 'All'], ['reseller', 'Resellers'], ['user', 'Users']].map(([k, l]) => (
            <button
              key={k}
              type="button"
              onClick={() => setRoleFilter(k)}
              className={`rounded-full px-3.5 py-1.5 text-[12.5px] font-semibold transition ${
                roleFilter === k ? 'bg-brand-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {l}
            </button>
          ))}
          <input
            className={`${inputCls} ml-auto max-w-[260px]`}
            placeholder="Search name, user ID, company…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </Card>

      <Card>
        <Table headers={['Account', 'Role', 'Under', 'Balance', 'Rate / SMS', 'Status', 'Created', 'Actions']}>
          {items.map((u) => (
            <tr key={u.id} className="transition hover:bg-gray-50/60">
              <Td>
                <div className="font-bold text-ink">{u.companyName}</div>
                <div className="text-[12px] text-gray-400">{u.name} · @{u.userId}</div>
              </Td>
              <Td>
                <span className={`inline-flex rounded-full px-2.5 py-[3px] text-[11.5px] font-bold capitalize ${ROLE_STYLES[u.role]}`}>
                  {u.role}
                </span>
              </Td>
              <Td>{u.parentName}</Td>
              <Td className="font-bold text-ink">{fmtMoney(u.balance)}</Td>
              <Td>${u.pricePerSms.toFixed(3)}</Td>
              <Td><Chip status={u.status === 'active' ? 'Active' : 'Pending'}>{u.status}</Chip></Td>
              <Td>{fmtDate(u.createdAt)}</Td>
              <Td>
                <div className="flex flex-wrap gap-1.5">
                  <Button variant="secondary" className="h-8 px-2.5 text-[12px]" onClick={() => setFund({ user: u, mode: 'fund', amount: '', note: '' })}>
                    Fund
                  </Button>
                  <Button variant="secondary" className="h-8 px-2.5 text-[12px]" onClick={() => setFund({ user: u, mode: 'deduct', amount: '', note: '' })}>
                    Deduct
                  </Button>
                  <Button variant="ghost" className="h-8 px-2.5 text-[12px] text-blue-600 bg-blue-50/50 hover:bg-blue-100" onClick={() => setDlt({ user: u, senders: '', templates: '' })}>DLT Config</Button><Button variant="ghost" className="h-8 px-2.5 text-[12px]" onClick={() => setEdit({ user: u, pricePerSms: String(u.pricePerSms), name: u.name, companyName: u.companyName, status: u.status })}>
                    Edit
                  </Button>
                </div>
              </Td>
            </tr>
          ))}
        </Table>
      </Card>

      {/* fund / deduct */}
      <Modal open={!!fund} onClose={() => setFund(null)} title={fund ? `${fund.mode === 'fund' ? 'Fund' : 'Deduct'} — ${fund.user.companyName}` : ''} width="max-w-md">
        {fund && (
          <div className="space-y-4">
            <div className="rounded-xl bg-[#fafbfc] p-3.5 text-[13px] text-gray-500">
              Current balance: <b className="text-ink">{fmtMoney(fund.user.balance)}</b>
              {me.role !== 'superadmin' && <> · Your balance: <b className="text-ink">{fmtMoney(me.balance)}</b></>}
            </div>
            <Field label="Amount (USD)">
              <input type="number" min="0" step="0.01" className={inputCls} value={fund.amount}
                onChange={(e) => setFund({ ...fund, amount: e.target.value })} placeholder="0.00" />
            </Field>
            <Field label="Note">
              <input className={inputCls} value={fund.note} onChange={(e) => setFund({ ...fund, note: e.target.value })} placeholder="e.g. Wallet top-up" />
            </Field>
            <div className="flex justify-end gap-2">
              <Button variant="secondary" onClick={() => setFund(null)}>Cancel</Button>
              <Button onClick={submitFund} disabled={busy || !+fund.amount}>Confirm</Button>
            </div>
          </div>
        )}
      </Modal>

      {/* edit */}
      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit ? `Edit — ${edit.user.userId}` : ''} width="max-w-md">
        {edit && (
          <div className="space-y-4">
            <Field label="Contact name">
              <input className={inputCls} value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
            </Field>
            <Field label="Company">
              <input className={inputCls} value={edit.companyName} onChange={(e) => setEdit({ ...edit, companyName: e.target.value })} />
            </Field>
            <Field label="Price per SMS (USD)" hint={me.role === 'reseller' ? `Cannot be below your cost ($${me.pricePerSms})` : undefined}>
              <input type="number" step="0.001" min="0" className={inputCls} value={edit.pricePerSms}
                onChange={(e) => setEdit({ ...edit, pricePerSms: e.target.value })} />
            </Field>
            <Field label="Status">
              <select className={inputCls} value={edit.status} onChange={(e) => setEdit({ ...edit, status: e.target.value })}>
                <option value="active">active</option>
                <option value="suspended">suspended</option>
              </select>
            </Field>
            <div className="flex justify-end gap-2">
              <Button variant="secondary" onClick={() => setEdit(null)}>Cancel</Button>
              <Button onClick={submitEdit} disabled={busy}>Save</Button>
            </div>
          </div>
        )}
      </Modal>

      {/* create */}
      <Modal open={!!create} onClose={() => setCreate(null)} title="New account" width="max-w-lg">
        {create && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Field label="User ID (login)">
                <input className={inputCls} value={create.userId} onChange={(e) => setCreate({ ...create, userId: e.target.value.toLowerCase() })} placeholder="e.g. acme01" />
              </Field>
              <Field label="Account type">
                <select className={inputCls} value={create.role} onChange={(e) => setCreate({ ...create, role: e.target.value })}>
                  <option value="user">User (SMS client)</option>
                  <option value="reseller">Reseller</option>
                </select>
              </Field>
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Field label="Contact name">
                <input className={inputCls} value={create.name} onChange={(e) => setCreate({ ...create, name: e.target.value })} placeholder="Jane Doe" />
              </Field>
              <Field label="Company">
                <input className={inputCls} value={create.companyName} onChange={(e) => setCreate({ ...create, companyName: e.target.value })} placeholder="Acme Pvt Ltd" />
              </Field>
            </div>
            <Field label="Email">
              <input className={inputCls} type="email" value={create.email} onChange={(e) => setCreate({ ...create, email: e.target.value })} placeholder="ops@acme.com" />
            </Field>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <Field label="Password">
                <input className={inputCls} value={create.password} onChange={(e) => setCreate({ ...create, password: e.target.value })} />
              </Field>
              <Field label="Rate / SMS">
                <input className={inputCls} type="number" step="0.001" value={create.pricePerSms} onChange={(e) => setCreate({ ...create, pricePerSms: e.target.value })} />
              </Field>
              <Field label="Initial funding">
                <input className={inputCls} type="number" min="0" value={create.initialFund} onChange={(e) => setCreate({ ...create, initialFund: e.target.value })} />
              </Field>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="secondary" onClick={() => setCreate(null)}>Cancel</Button>
              <Button onClick={submitCreate} disabled={busy || !create.userId || !create.name || !create.password}>Create account</Button>
            </div>
          </div>
        )}
      </Modal>
      <Modal open={!!dlt} onClose={() => setDlt(null)} title={dlt ? `DLT Config - ${dlt.user.userId}` : ''} width="max-w-xl">
        {dlt && (
          <div className="space-y-4">
            <div className="text-[13px] text-gray-500">
              Assign specific Sender IDs and Templates for <b className="text-ink">{dlt.user.companyName}</b>.
            </div>
            <Field label="Sender IDs (comma separated)">
              <input className={inputCls} value={dlt.senders} onChange={(e) => setDlt({...dlt, senders: e.target.value})} placeholder="e.g. NEXORA, ALERTS" />
            </Field>
            <Field label="Templates (comma separated IDs)">
              <textarea className={inputCls} rows={4} value={dlt.templates} onChange={(e) => setDlt({...dlt, templates: e.target.value})} placeholder="e.g. TPL01, TPL02" />
            </Field>
            <div className="flex justify-end gap-2">
              <Button variant="secondary" onClick={() => setDlt(null)}>Cancel</Button>
              <Button onClick={submitDlt} disabled={busy}>Save Configuration</Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}
